<?php

/**
 * Class WC_Wampum_Gateway
 *
 * Extension of WC_Payment_Gateway class to create Wampum Payment Gateway
 *
 * This class extends the WooCommerce payment gateway class to generate our admin area settings
 * forms and include the gateway in available gateway choices for users.
 */
class WC_Wampum_Gateway extends WC_Payment_Gateway {
	
	public function __construct() {
		
		/**
		 * @var string  $id                     ID of the payment gateway
		 * @var string  $icon                   URL to image file for icon to appear during checkout
		 * @var bool    $has_fields             If gateway requires form fields during checkout
		 * @var string  $method_title           Visual name of the gateway
		 * @var string  $method_description     Description that appear in admin area
		 */
		
		$this->id                 = 'wampum';
		$this->icon               = '';
		$this->has_fields         = FALSE;
		$this->method_title       = 'Wampum Bitcoin';
		$this->method_description = 'Use Bitcoin for purchases with Wampum';
		$this->supports 	      = array(
			'subscriptions',
			'products'
		);
		
		$this->init_form_fields();
		$this->init_settings();
		
		
		$this->title = $this->get_option( 'title' );
		
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array(
			$this,
			'process_admin_options'
		) );
		
	}
	
	
	/**
	 * Define our settings form fields for setting up the gateway.
	 */
	public function init_form_fields() {
		
		$this->form_fields = array(
			'enabled'      => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-wampum' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Wampum Bitcoin Payment', 'woocommerce-wampum' ),
				'default' => 'no'
			),
			'title'        => array(
				'title'       => __( 'Title', 'woocommerce-wampum' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-wampum' ),
				'default'     => __( 'Wampum Bitcoin', 'woocommerce-wampum' ),
				'desc_tip'    => TRUE,
			),
			'description'  => array(
				'title'   => __( 'Customer Message', 'woocommerce-wampum' ),
				'type'    => 'textarea',
				'default' => ''
			),
			'api_url'      => array(
				'title'       => __( 'Wampum URL', 'woocommerce-wampum' ),
				'type'        => 'url',
				'description' => __( 'Your Wampum issued API URL', 'woocommerce-wampum' )
			),
			'api_username' => array(
				'title'       => __( 'Wampum Username', 'woocommerce-wampum' ),
				'type'        => 'text',
				'description' => __( 'Your Wampum issued API username', 'woocommerce-wampum' )
			),
			'api_password' => array(
				'title'       => __( 'Wampum Password', 'woocommerce-wampum' ),
				'type'        => 'text',
				'description' => __( 'Your  Wampum issued API password', 'woocommerce-wampum' )
			)
		);
		
	}
	
	
	/**
	 * Trigger the necessary functionality to process an order and add it to the database, output messages etc.
	 *
	 * @param int $order_id
	 *
	 * @return array
	 */
	public function process_payment( $order_id ) {
		
		global $woocommerce;
		
		$order = new WC_Order( $order_id );
		
		//Mark as processing until we've checked invoice payment status
		$order->update_status( 'on-hold', __( 'System is validating payment reception', 'woocommerce' ) );
		$order->add_order_note( sprintf( __( 'Wampum charge processing', 'woocommerce-gateway-wampum' ) ) );
		
		//Reduce Stock Level
		$order->reduce_order_stock();
		
		//Clear the cart of the order items
		$woocommerce->cart->empty_cart();
		
		//Generate thankyou redirect
		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order )
		);
		
	}
	
}
