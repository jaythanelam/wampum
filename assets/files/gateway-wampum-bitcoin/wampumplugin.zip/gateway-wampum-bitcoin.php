<?php
/**
 * @author Wampum, LLC
 * @copyright Wampum, LLC
 * @license GPLv2 or later 
 *
 * @wordpress-plugin
 * Plugin Name: Woo Gateway Wampum Bitcoin
 * Plugin URI: http://cryptowampum.com/files/gateway-wampum-bitcoin/
 * Description: Allows WooCommerce to leverage Wampum Register© Merchant wallet for accepting Bitcoin without a third party
 * License: GPLv2 or later 
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html

 * Author: Wampum, LLC
 * Author URI: http://cryptowampum.com
 * Version: 1.0.3
 */


/**
 * Run the Wampum gateway with necessary checks to make sure running it is valid
 * Note that the currency is setup in Wampum Register instance!
 *
 * @return WC_Wampum_Gateway    Wampum Payment Gateway
 */
function init_wampum_gateway(){
		
	if ( class_exists( 'WooCommerce' ) ) {
		
		if( get_woocommerce_currency() == 'USD' ) {
			
			require_once( plugin_dir_path( __FILE__ ) . 'class-wampum-gateway.php' );
			wp_enqueue_style( 'wampum', plugin_dir_url( __FILE__ ) . '/css/style.css' );
			
			function add_wampum_gateway( $methods ){
				
				$methods[] = 'WC_Wampum_Gateway';
				return $methods;
				
			}
			
			add_filter( 'woocommerce_payment_gateways', 'add_wampum_gateway' );

			return new WC_Wampum_Gateway();
			
		} elseif (get_woocommerce_currency() == 'EUR') {
			
			wp_enqueue_style( 'wampum', plugin_dir_url( __FILE__ ) . '/css/style.css' );
			
			function add_wampum_gateway( $methods ){
				
				$methods[] = 'WC_Wampum_Gateway';
				return $methods;
				
			}
			
			add_filter( 'woocommerce_payment_gateways', 'add_wampum_gateway' );

			return new WC_Wampum_Gateway();
			
		} else {
			
			function wampum_admin__error( $message = NULL ) {
				
				echo '<div class="notice notice-error is-dismissible">';
				echo __( '<p><strong>WooCommerce Wampum Disabled.</strong> Wampum currently only supports United States Dollar store currency.</p>', 'wampum' );
				echo '</div>';
				
			}
			
			add_action( 'admin_notices', 'wampum_admin__error' );
			
		}
		
	} else {
		
		
		function wampum_admin__error( $message = NULL ) {
			
			echo '<div class="notice notice-error is-dismissible">';
			echo __( '<p>WooCommerce must be active for WooCommerce Wampum Gateway to work. Please activate WooCommerce.</p>', 'wampum' );
			echo '</div>';
			
		}
	
		add_action( 'admin_notices', 'wampum_admin__error' );
	
	}
	

}

add_action( 'plugins_loaded', 'init_wampum_gateway' );


/**
 * Run the Wampum API class
 *
 * @param $order_id WooCommerce Order ID
 */
function wampum_init( $order_id ){
	
	require_once( plugin_dir_path(__FILE__) . 'class-wampum-api.php' );
	
	$wampum = new Wampum();

	return $wampum->process_invoice( $order_id );
	
}

add_action( 'woocommerce_thankyou_wampum', 'wampum_init' );


/**
 * Register new schedule
 */
function register_wampum_schedule( $schedules ) {
	
	$schedules['twenty_min'] = array(
		'interval' => 1200,
		'display' => __('Every 20 Minutes')
	);
	
	return $schedules;
	
}

add_filter( 'cron_schedules', 'register_wampum_schedule' );


/**
 * Register Wampum scheduled action on plugin activation
 */
function register_wampum_cron() {
	
	if( ! wp_next_scheduled('wampum_update_orders')) {
	
		wp_schedule_event( time(), 'twenty_min', 'wampum_update_orders' );
	
	}

}

register_activation_hook(__FILE__, 'register_wampum_cron');


/**
 * Trigger the scheduled order update loop
 */
function wampum_update_order_status(){
	
	require_once( plugin_dir_path( __FILE__ ) . 'class-wampum-api.php' );
	
	$wampum = new Wampum();
	
	$wampum->update_orders();
	
}

add_action( 'wampum_update_orders', 'wampum_update_order_status' );


/**
 * Remove scheduled action on plugin deactivation
 */
function deregister_wampum_cron(){
	
	wp_clear_scheduled_hook( 'wampum_update_orders' );
	
}

register_deactivation_hook( __FILE__, 'deregister_wampum_cron' );